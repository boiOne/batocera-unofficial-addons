#!/bin/bash
# install_gamescope_v42.sh - Install / enable Gamescope v42 via Batocera service

set -e

G_BASE="/userdata/system/gamescope"
SERVICE_DST="/userdata/system/services/gamescope_service"
SERVICE_SRC="${G_BASE}/gamescope_service"

echo "=== Installing Gamescope v42 (service-based) ==="

# ---------------------------------------------------------------------------
# 1) Sanity checks
# ---------------------------------------------------------------------------

if [ ! -d "$G_BASE" ]; then
    echo "ERROR: Gamescope base directory not found: $G_BASE" >&2
    exit 1
fi

if [ ! -f "$SERVICE_SRC" ]; then
    echo "ERROR: Service script not found: $SERVICE_SRC" >&2
    echo "Make sure gamescope_service is present in $G_BASE." >&2
    exit 1
fi

# ---------------------------------------------------------------------------
# 2) Ensure force_exit helper is executable
# ---------------------------------------------------------------------------

if [ -f "${G_BASE}/force_exit_wine_steam_gamescope.sh" ]; then
    echo "Setting executable bit on force_exit_wine_steam_gamescope.sh..."
    chmod 775 "${G_BASE}/force_exit_wine_steam_gamescope.sh"
else
    echo "WARNING: ${G_BASE}/force_exit_wine_steam_gamescope.sh not found." >&2
fi

# ---------------------------------------------------------------------------
# 3) Install / update gamescope_service
# ---------------------------------------------------------------------------

echo "Installing gamescope_service into /userdata/system/services/…"

mkdir -p "$(dirname "$SERVICE_DST")"
cp "$SERVICE_SRC" "$SERVICE_DST"
chmod 775 "$SERVICE_DST"

# ---------------------------------------------------------------------------
# 4) Enable + start service
# ---------------------------------------------------------------------------

echo "Enabling and starting gamescope_service via batocera-services…"

if command -v batocera-services >/dev/null 2>&1; then
    # Ignore failures (e.g. already enabled)
    batocera-services enable gamescope_service 2>/dev/null || true
    batocera-services start  gamescope_service 2>/dev/null || true
else
    echo "WARNING: batocera-services command not found; enable/start it manually." >&2
fi

echo
echo "=== Gamescope v42 service installation complete ==="
echo "Gamescope symlinks should now be in place for this session."
echo "For a clean test from boot, REBOOT Batocera so the service runs early in startup."
