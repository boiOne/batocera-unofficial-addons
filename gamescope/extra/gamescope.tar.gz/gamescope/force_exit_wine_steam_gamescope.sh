#!/bin/bash
#
# force_exit_wine_steam_gamescope.sh
# Cleanly (then forcefully) stop Wine, Steam and all Gamescope-related processes
# using pidof for binaries and pgrep -f for wrapper scripts.

#######################################
# Helpers
#######################################

kill_by_pidof() {
    local sig="$1"   # TERM or KILL
    local name="$2"  # process name as seen by pidof
    local pids

    pids="$(pidof "$name" 2>/dev/null)" || return 0

    for pid in $pids; do
        kill "-$sig" "$pid" 2>/dev/null || true
    done
}

kill_by_pattern() {
    local sig="$1"      # TERM or KILL
    local pattern="$2"  # grep pattern used by pgrep -f
    local pids

    pids="$(pgrep -f "$pattern" 2>/dev/null)" || return 0

    for pid in $pids; do
        # Don't ever kill this script itself, just in case
        [ "$pid" = "$$" ] && continue
        kill "-$sig" "$pid" 2>/dev/null || true
    done
}

#######################################
# Graceful pass
#######################################

echo "[force-exit] Graceful shutdown pass..."

# Wine / Steam core processes (pidof == real binaries)
kill_by_pidof TERM batocera-wine
kill_by_pidof TERM steam
kill_by_pidof TERM winedevice.exe
kill_by_pidof TERM wineserver

# Gamescope wrappers + helpers (scripts / weird naming)
kill_by_pattern TERM "gamescope-wl"
kill_by_pattern TERM "gamescopereaper"
# If you ever see a plain 'gamescope' process in pgrep -fl, you can add:
# kill_by_pidof TERM gamescope  # if it's an ELF binary
# or:
# kill_by_pattern TERM "gamescope "  # if it's another wrapper

sleep 1

#######################################
# Hard kill pass
#######################################

echo "[force-exit] Hard kill pass..."

kill_by_pidof KILL batocera-wine
kill_by_pidof KILL steam
kill_by_pidof KILL winedevice.exe
kill_by_pidof KILL wineserver

kill_by_pattern KILL "gamescope-wl"
kill_by_pattern KILL "gamescopereaper"
# Optionally, same comment as above:
# kill_by_pidof KILL gamescope
# or kill_by_pattern KILL "gamescope "

echo "[force-exit] Done."
