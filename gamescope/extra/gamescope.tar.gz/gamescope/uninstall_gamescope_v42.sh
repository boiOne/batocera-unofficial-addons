#!/bin/bash
# uninstall_gamescope_v42.sh - Remove Gamescope v42 service

set -e

SERVICE="/userdata/system/services/gamescope_service"

echo "=== Uninstalling Gamescope v42 service ==="

if [ -f "$SERVICE" ]; then
    if command -v batocera-services >/dev/null 2>&1; then
        batocera-services stop    gamescope_service 2>/dev/null || true
        batocera-services disable gamescope_service 2>/dev/null || true
    fi

    rm -f "$SERVICE"
    echo "Removed service script: $SERVICE"
else
    echo "Service script not found at $SERVICE (already removed?)."
fi

echo
echo "On next reboot, Gamescope overrides will no longer be applied."
echo "No overlay changes are persisted; the stock filesystem will come back after reboot."
