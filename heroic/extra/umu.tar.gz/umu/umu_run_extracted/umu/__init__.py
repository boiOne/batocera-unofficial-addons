__version__ = "1.2.9"  # noqa: D104
__runtime_versions__ = (
    ("sniper", "steamrt3", "1628350"),
    ("soldier", "steamrt2", "1391110"),
)
__runtime_version__ = __runtime_versions__[0]
