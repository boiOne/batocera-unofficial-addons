#!/usr/bin/env python3
import os
import sys
import runpy

# Base directory (?/runtimes/umu)
base = os.path.dirname(os.path.abspath(__file__))

# Folder that contains __main__.py and the "umu" package
extracted = os.path.join(base, "umu_run_extracted")

# Make sure Python can import "umu" from umu_run_extracted
if extracted not in sys.path:
    sys.path.insert(0, extracted)

# Path to the real UMU __main__.py
main = os.path.join(extracted, "__main__.py")

# Fix argv so UMU behaves correctly
sys.argv[0] = main

# Run UMU patched main
runpy.run_path(main, run_name="__main__")
